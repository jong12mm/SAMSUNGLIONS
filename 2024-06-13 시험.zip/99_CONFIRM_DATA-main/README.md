# CONFIRM_DATA
## 조별 확인자료 확인 REPOSITORY입니다.
2024-01-17 화면구현 평가예시
---
1조 : 클론코딩(서브웨이) (or 기존레이아웃변형)

홍길동 : 메인페이지(https://www.subway.co.kr/) <br/>
남길동 : 메뉴소개>샌드위치(https://www.subway.co.kr/menuList/sandwich)<br/>

2024-01-13,14 연습
---
##### 01 HTML/CSS 클론페이지 레이아웃
##### 02 HTML/CSS 클론페이지 디테일링


2024-01-25 
---
##### 1차 조 변경 이후 DB 설계(개념적 설계연습)
##### 1차 조 변경 이후 DB 설계(논리적 설계연습)

