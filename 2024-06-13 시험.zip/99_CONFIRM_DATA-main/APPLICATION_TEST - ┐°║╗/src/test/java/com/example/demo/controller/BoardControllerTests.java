package com.example.demo.controller;


import com.example.demo.domain.dto.BoardDto;
import com.example.demo.restcontroller.BoardRestController;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(value={BoardController.class, BoardRestController.class})
public class BoardControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void t4() throws Exception {

        BoardDto boardDto = new BoardDto(1L,"test1","test2","test3");

        this.mockMvc.perform(
                MockMvcRequestBuilders
                        .get("/board/list")
                        .param("boardDto" ,String.valueOf(boardDto))


        ).andExpect(MockMvcResultMatchers.status().isOk())
                .andDo(print());

    }




}
